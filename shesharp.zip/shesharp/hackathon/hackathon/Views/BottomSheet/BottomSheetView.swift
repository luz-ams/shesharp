//
//  BottomSheetView.swift
//  hackathon
//
//  Created by Luz Racca on 10/06/2023.
//

import Foundation
import SwiftUI

struct BottomSheetView: View {
    @Binding var isSheetPresented: Bool
    
    var body: some View {
        VStack {
            Text("Halfway Sheet Content")
                .font(.headline)
                .padding()
            
            Button("Dismiss") {
                isSheetPresented.toggle()
            }
            .padding()
        }
        .background(Color.white)
        .frame(maxWidth: .infinity)
        .cornerRadius(10)
        .shadow(radius: 5)
        .padding()
    }
}
